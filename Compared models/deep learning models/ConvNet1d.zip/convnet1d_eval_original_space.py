import os
import json
import math
import glob
import csv
import random
from typing import Dict, List, Tuple, Optional

import numpy as np
import pandas as pd

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

RESULTS_DIR = r"C:\Users\admin\Desktop\下游数据智能化分析\力曲线智能识别训练数据\Sotres2022_ConvNet1D_结果3 （200 epoch）"
DATA_DIR = r"C:\Users\admin\Desktop\下游数据智能化分析\力曲线智能识别训练数据\组织+细胞"
LABELS_EXCEL = r"C:\Users\admin\Desktop\下游数据智能化分析\力曲线智能识别训练数据\组织+细胞\contact_points_labels.xlsx"

BEST_MODEL_PATH: Optional[str] = None
TEST_FILES_PATH: Optional[str] = None

EVAL_BATCH_SIZE = 1024
EVAL_NUM_WORKERS = 0
NUM_VISUALIZE = 20
DEVICE = "cuda"

THRESHOLDS = [5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 200, 500]

class ConvNet1D(nn.Module):
    def __init__(self, n_points: int, l2_reg: float = 1e-4):
        super().__init__()
        self.n_points = n_points

        self.features = nn.Sequential(
            nn.Conv1d(1, 32, kernel_size=9, padding=4),
            nn.ReLU(inplace=True),
            nn.MaxPool1d(kernel_size=2, stride=2),

            nn.Conv1d(32, 64, kernel_size=9, padding=4),
            nn.ReLU(inplace=True),
            nn.MaxPool1d(kernel_size=2, stride=2),

            nn.Conv1d(64, 128, kernel_size=9, padding=4),
            nn.ReLU(inplace=True),
            nn.MaxPool1d(kernel_size=2, stride=2),
        )

        flat_size = 128 * (n_points // 8)
        self.regressor = nn.Sequential(
            nn.Flatten(),
            nn.Linear(flat_size, 128),
            nn.Linear(128, 1),
        )
        self.l2_reg = l2_reg

    def forward(self, x):
        x = self.features(x)
        x = self.regressor(x)
        return x


class AFMDatasetSotres(Dataset):
    def __init__(self, file_list: List[str], labels_dict: Dict[str, int],
                 data_dir: str, n_points: int = 5120):
        self.file_list = list(file_list)
        self.labels_dict = labels_dict
        self.data_dir = data_dir
        self.n_points = n_points

    def __len__(self):
        return len(self.file_list)

    def _load_deflection(self, filename: str) -> np.ndarray:
        filepath = os.path.join(self.data_dir, filename)
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
        data = []
        for line in lines:
            line = line.strip()
            if not line:
                continue
            try:
                data.append(float(line))
            except ValueError:
                continue
        data = np.asarray(data, dtype=np.float64)
        return data[:len(data) // 2]

    def _resample(self, deflection: np.ndarray, contact_idx: int,
                  orig_len: int) -> Tuple[np.ndarray, int]:
        x_old = np.linspace(0, 1, orig_len)
        x_new = np.linspace(0, 1, self.n_points)
        defl_rs = np.interp(x_new, x_old, deflection)
        ratio = self.n_points / orig_len
        new_idx = int(np.clip(contact_idx * ratio, 0, self.n_points - 1))
        return defl_rs, new_idx

    @staticmethod
    def _normalize_sotres(arr: np.ndarray) -> np.ndarray:
        rng = arr.max() - arr.min()
        if rng < 1e-8:
            rng = 1.0
        return (arr - arr.mean()) / rng

    def __getitem__(self, idx: int):
        filename = self.file_list[idx]
        contact_idx = int(self.labels_dict[filename])
        deflection = self._load_deflection(filename)
        orig_len = len(deflection)

        defl_rs, new_idx = self._resample(deflection, contact_idx, orig_len)
        defl_norm = self._normalize_sotres(defl_rs)
        pos_label = new_idx / self.n_points

        return {
            'signal': torch.tensor(defl_norm, dtype=torch.float32).unsqueeze(0),
            'position': torch.tensor(pos_label, dtype=torch.float32),
            'resampled_contact_idx': int(new_idx),
            'original_length': int(orig_len),
            'filename': filename,
            'original_contact_idx': int(contact_idx),
        }


def _latest_file(patterns: List[str], required: bool = True) -> Optional[str]:
    candidates = []
    for p in patterns:
        candidates.extend(glob.glob(p))
    candidates = [p for p in candidates if os.path.isfile(p)]
    if not candidates:
        if required:
            raise FileNotFoundError("未找到文件，匹配模式：" + " | ".join(patterns))
        return None
    return max(candidates, key=os.path.getmtime)


def resolve_paths(results_dir: str) -> Tuple[str, str, str]:
    os.makedirs(results_dir, exist_ok=True)

    if BEST_MODEL_PATH is not None and str(BEST_MODEL_PATH).strip():
        model_path = BEST_MODEL_PATH
    else:
        exact = os.path.join(results_dir, 'best_val_loss.pth')
        if os.path.exists(exact):
            model_path = exact
        else:
            model_path = _latest_file([
                os.path.join(results_dir, 'best_val_loss*.pth'),
                os.path.join(results_dir, '*.pth'),
            ])

    if TEST_FILES_PATH is not None and str(TEST_FILES_PATH).strip():
        test_files_path = TEST_FILES_PATH
    else:
        exact = os.path.join(results_dir, 'test_files.json')
        if os.path.exists(exact):
            test_files_path = exact
        else:
            test_files_path = _latest_file([
                os.path.join(results_dir, 'test_files*.json'),
            ])

    output_dir = os.path.join(results_dir, 'sotres_convnet1d_original_space_eval')
    os.makedirs(output_dir, exist_ok=True)
    return model_path, test_files_path, output_dir


def load_labels(excel_path: str) -> Dict[str, int]:
    df = pd.read_excel(excel_path)
    required = {'FileName', 'ContactIndex'}
    if not required.issubset(set(df.columns)):
        raise ValueError(f"标签表必须包含列：{required}，当前列：{list(df.columns)}")
    labels_dict = {}
    for _, row in df.iterrows():
        labels_dict[str(row['FileName'])] = int(row['ContactIndex'])
    return labels_dict


def load_test_files(test_files_path: str) -> List[str]:
    with open(test_files_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    if not isinstance(data, list):
        raise ValueError(f"test_files.json 应该是 list，但读取到：{type(data)}")
    return [str(x) for x in data]


def load_model(model_path: str, device: torch.device) -> Tuple[ConvNet1D, dict]:
    try:
        ckpt = torch.load(model_path, map_location=device, weights_only=False)
    except TypeError:
        ckpt = torch.load(model_path, map_location=device)

    if not isinstance(ckpt, dict):
        raise ValueError("checkpoint 不是 dict，无法解析。")

    config = ckpt.get('config', {})
    n_points = int(config.get('n_points', 5120))
    model = ConvNet1D(n_points=n_points, l2_reg=1e-4).to(device)

    state_dict = ckpt.get('model_state_dict', ckpt)
    if any(k.startswith('module.') for k in state_dict.keys()):
        state_dict = {k[7:]: v for k, v in state_dict.items()}
    model.load_state_dict(state_dict)
    model.eval()

    print(f"[Model] Loaded: {model_path}")
    print(f"        n_points={n_points}, epoch={ckpt.get('epoch', 'N/A')}, "
          f"val_loss={ckpt.get('val_loss', 'N/A')}")
    return model, config


def make_test_loader(test_files: List[str], labels_dict: Dict[str, int],
                     data_dir: str, n_points: int) -> DataLoader:
    valid = []
    missing_label, missing_file = 0, 0
    for fn in test_files:
        if fn not in labels_dict:
            missing_label += 1
            continue
        if not os.path.exists(os.path.join(data_dir, fn)):
            missing_file += 1
            continue
        valid.append(fn)

    if missing_label or missing_file:
        print(f"[Warn] 跳过无标签文件 {missing_label} 个；跳过找不到 txt 的文件 {missing_file} 个。")
    if not valid:
        raise RuntimeError("没有可评估的测试文件，请检查 DATA_DIR、LABELS_EXCEL 和 test_files.json。")

    ds = AFMDatasetSotres(valid, labels_dict, data_dir, n_points=n_points)
    pin_memory = torch.cuda.is_available() and str(DEVICE).lower().startswith('cuda')
    return DataLoader(
        ds,
        batch_size=EVAL_BATCH_SIZE,
        shuffle=False,
        num_workers=EVAL_NUM_WORKERS,
        pin_memory=pin_memory,
    )


@torch.no_grad()
def evaluate(model: ConvNet1D, loader: DataLoader,
             device: torch.device, n_points: int) -> pd.DataFrame:
    model.eval()
    rows = []

    for batch in loader:
        signal = batch['signal'].to(device, non_blocking=True)
        pred_norm = model(signal).squeeze(1).detach().cpu().numpy()

        pred_rs = np.clip((pred_norm * n_points).astype(np.int64), 0, n_points - 1)

        gt_rs = batch['resampled_contact_idx'].numpy().astype(np.int64)
        gt_orig = batch['original_contact_idx'].numpy().astype(np.int64)
        orig_len = batch['original_length'].numpy().astype(np.int64)
        filenames = list(batch['filename'])

        for fn, pn, pr, gr, go, ol in zip(filenames, pred_norm, pred_rs, gt_rs, gt_orig, orig_len):
            pred_orig = int(np.clip(pr * ol / n_points, 0, ol - 1))
            err_orig = int(abs(pred_orig - int(go)))
            err_rs = int(abs(int(pr) - int(gr)))
            rows.append({
                'filename': fn,
                'pred_orig': pred_orig,
                'gt_orig': int(go),
                'error_orig': err_orig,
                'pred_rs': int(pr),
                'gt_rs': int(gr),
                'error_rs': err_rs,
                'pred_norm': float(pn),
                'original_length': int(ol),
                'resample_ratio': float(ol / n_points),
            })

    df = pd.DataFrame(rows)
    if df.empty:
        raise RuntimeError("评估结果为空。")
    return df


def compute_metrics(errors: np.ndarray) -> Tuple[dict, List[dict]]:
    metrics = {
        'Samples': int(len(errors)),
        'MAE (pts)': float(np.mean(errors)),
        'MedAE (pts)': float(np.median(errors)),
        'Std (pts)': float(np.std(errors)),
        'Max Error (pts)': float(np.max(errors)),
    }

    cumulative = []
    for t in THRESHOLDS:
        pct = float(np.mean(errors <= t) * 100.0)
        key = f'<= {t} pts (%)'
        metrics[key] = pct
        cumulative.append({
            'threshold_pts': int(t),
            'accuracy_percent': pct,
            'count': int(np.sum(errors <= t)),
            'total': int(len(errors)),
        })
    return metrics, cumulative


def save_reports(df: pd.DataFrame, metrics: dict, cumulative: List[dict],
                 output_dir: str, model_path: str, test_files_path: str,
                 n_points: int) -> None:
    df_sorted = df.sort_values('error_orig', ascending=False).reset_index(drop=True)
    df_sorted.insert(0, 'rank_by_error', np.arange(1, len(df_sorted) + 1))

    full_csv = os.path.join(output_dir, 'sotres_convnet1d_evaluation_results_original_space.csv')
    df_sorted.to_csv(full_csv, index=False, encoding='utf-8-sig')

    metrics_csv = os.path.join(output_dir, 'sotres_convnet1d_original_space_metrics.csv')
    with open(metrics_csv, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(['metric', 'value'])
        for k, v in metrics.items():
            w.writerow([k, v])

    cum_csv = os.path.join(output_dir, 'sotres_convnet1d_cumulative_accuracy_original_space.csv')
    pd.DataFrame(cumulative).to_csv(cum_csv, index=False, encoding='utf-8-sig')

    metrics_json = os.path.join(output_dir, 'sotres_convnet1d_original_space_metrics.json')
    with open(metrics_json, 'w', encoding='utf-8') as f:
        json.dump({
            'model': 'ConvNet-1D (Sotres et al. 2022)',
            'space': 'original',
            'unit': 'pts',
            'n_points': int(n_points),
            'model_path': model_path,
            'test_files_path': test_files_path,
            'metrics': metrics,
            'cumulative_accuracy': cumulative,
        }, f, ensure_ascii=False, indent=2)

    summary_txt = os.path.join(output_dir, 'sotres_convnet1d_evaluation_summary_original_space.txt')
    with open(summary_txt, 'w', encoding='utf-8') as f:
        f.write('Sotres et al. 2022 — ConvNet-1D Evaluation Summary\n')
        f.write('=' * 70 + '\n')
        f.write(f'Model path: {model_path}\n')
        f.write(f'Test files: {test_files_path}\n')
        f.write(f'n_points: {n_points}\n')
        f.write('Evaluation space: Original Space\n')
        f.write('Unit: pts\n')
        f.write('=' * 70 + '\n\n')
        f.write(f"Samples: {metrics['Samples']}\n")
        f.write(f"MAE (pts): {metrics['MAE (pts)']:.4f}\n")
        f.write(f"MedAE (pts): {metrics['MedAE (pts)']:.4f}\n")
        f.write(f"Std (pts): {metrics['Std (pts)']:.4f}\n")
        f.write(f"Max Error (pts): {metrics['Max Error (pts)']:.4f}\n\n")
        f.write('Cumulative Accuracy (Original Space):\n')
        for item in cumulative:
            f.write(f"  <= {item['threshold_pts']:>3d} pts: "
                    f"{item['accuracy_percent']:>6.2f}% "
                    f"({item['count']}/{item['total']})\n")

    print(f"[Saved] {full_csv}")
    print(f"[Saved] {metrics_csv}")
    print(f"[Saved] {cum_csv}")
    print(f"[Saved] {metrics_json}")
    print(f"[Saved] {summary_txt}")


def plot_error_distribution(errors: np.ndarray, output_dir: str) -> None:
    fig, ax1 = plt.subplots(figsize=(10, 6))
    ax1.hist(errors, bins=50, alpha=0.75, edgecolor='black')
    ax1.set_xlabel('Absolute Error in Original Space (pts)')
    ax1.set_ylabel('Count')
    ax1.set_title('ConvNet-1D Error Distribution (Original Space)')
    ax1.grid(True, alpha=0.3)

    ax2 = ax1.twinx()
    x_sorted = np.sort(errors)
    y = np.arange(1, len(x_sorted) + 1) / len(x_sorted) * 100
    ax2.plot(x_sorted, y, linewidth=2)
    ax2.set_ylabel('Cumulative Accuracy (%)')
    ax2.set_ylim(0, 100)

    for t in THRESHOLDS:
        ax1.axvline(t, linestyle='--', linewidth=0.8, alpha=0.35)

    plt.tight_layout()
    out = os.path.join(output_dir, 'sotres_convnet1d_error_distribution_original_space.png')
    plt.savefig(out, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"[Saved] {out}")


def plot_pred_vs_gt(df: pd.DataFrame, output_dir: str) -> None:
    fig, ax = plt.subplots(figsize=(8, 8))
    ax.scatter(df['gt_orig'], df['pred_orig'], s=10, alpha=0.55)
    lo = int(min(df['gt_orig'].min(), df['pred_orig'].min()))
    hi = int(max(df['gt_orig'].max(), df['pred_orig'].max()))
    ax.plot([lo, hi], [lo, hi], linestyle='--', linewidth=1.5)
    ax.set_xlabel('Ground Truth Contact Point (Original pts)')
    ax.set_ylabel('Predicted Contact Point (Original pts)')
    ax.set_title('ConvNet-1D Predicted vs Ground Truth (Original Space)')
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    out = os.path.join(output_dir, 'sotres_convnet1d_pred_vs_gt_original_space.png')
    plt.savefig(out, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"[Saved] {out}")


def visualize_predictions(df: pd.DataFrame, data_dir: str, output_dir: str,
                          num_samples: int = 20) -> None:
    n = min(num_samples, len(df))
    if n <= 0:
        return

    selected = df.sample(n=n, random_state=42).reset_index(drop=True)
    nc = 4
    nr = math.ceil(n / nc)
    fig, axes = plt.subplots(nr, nc, figsize=(20, 4 * nr))
    axes = np.array(axes).reshape(-1)

    for i, row in selected.iterrows():
        ax = axes[i]
        fn = row['filename']
        try:
            filepath = os.path.join(data_dir, fn)
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                values = []
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        values.append(float(line))
                    except ValueError:
                        continue
            values = np.asarray(values, dtype=np.float64)
            deflection = values[:len(values) // 2]
            x = np.arange(len(deflection))
            pred = int(row['pred_orig'])
            gt = int(row['gt_orig'])
            err = int(row['error_orig'])

            ax.plot(x, deflection, linewidth=0.7)
            ax.axvline(pred, linestyle='--', linewidth=1.5, label=f'Pred:{pred}')
            ax.axvline(gt, linestyle=':', linewidth=1.5, label=f'GT:{gt}')
            if 0 <= pred < len(deflection):
                ax.plot(pred, deflection[pred], 'o', markersize=6)
            if 0 <= gt < len(deflection):
                ax.plot(gt, deflection[gt], 'o', markersize=6, fillstyle='none')
            ax.set_title(f'{fn}\nErr={err} pts', fontsize=8)
            ax.legend(fontsize=7)
            ax.grid(True, alpha=0.3)
        except Exception as e:
            ax.set_title(f'{fn}\nError: {e}', fontsize=8)
            ax.axis('off')

    for j in range(n, len(axes)):
        axes[j].axis('off')

    plt.suptitle('ConvNet-1D Contact Point Predictions', fontsize=13, y=1.01)
    plt.tight_layout()
    out = os.path.join(output_dir, 'sotres_convnet1d_prediction_visualization.png')
    plt.savefig(out, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"[Saved] {out}")


def print_metrics(metrics: dict, cumulative: List[dict]) -> None:
    print('\n' + '=' * 70)
    print('Sotres et al. 2022 — ConvNet-1D | Original Space Metrics')
    print('=' * 70)
    print(f"Samples:          {metrics['Samples']}")
    print(f"MAE (pts):        {metrics['MAE (pts)']:.4f}")
    print(f"MedAE (pts):      {metrics['MedAE (pts)']:.4f}")
    print(f"Std (pts):        {metrics['Std (pts)']:.4f}")
    print(f"Max Error (pts):  {metrics['Max Error (pts)']:.4f}")
    print('\nCumulative Accuracy (Original Space):')
    for item in cumulative:
        print(f"  <= {item['threshold_pts']:>3d} pts: "
              f"{item['accuracy_percent']:>6.2f}% "
              f"({item['count']}/{item['total']})")
    print('=' * 70 + '\n')


def main():
    print('\n' + '=' * 70)
    print('Sotres et al. 2022 — ConvNet-1D Evaluation Only')
    print('不重新训练：直接加载 best_val_loss.pth + test_files.json')
    print('=' * 70)

    for path, name in [(RESULTS_DIR, 'RESULTS_DIR'), (DATA_DIR, 'DATA_DIR'), (LABELS_EXCEL, 'LABELS_EXCEL')]:
        if not os.path.exists(path):
            raise FileNotFoundError(f'{name} 不存在：{path}')

    model_path, test_files_path, output_dir = resolve_paths(RESULTS_DIR)
    print(f'[Path] RESULTS_DIR:     {RESULTS_DIR}')
    print(f'[Path] BEST_MODEL_PATH: {model_path}')
    print(f'[Path] TEST_FILES_PATH: {test_files_path}')
    print(f'[Path] OUTPUT_DIR:      {output_dir}')

    device = torch.device(DEVICE if torch.cuda.is_available() and DEVICE.startswith('cuda') else 'cpu')
    print(f'[Device] {device}')

    model, config = load_model(model_path, device)
    n_points = int(config.get('n_points', 5120))

    labels_dict = load_labels(LABELS_EXCEL)
    test_files = load_test_files(test_files_path)
    loader = make_test_loader(test_files, labels_dict, DATA_DIR, n_points=n_points)

    df = evaluate(model, loader, device, n_points=n_points)
    errors = df['error_orig'].to_numpy(dtype=np.float64)
    metrics, cumulative = compute_metrics(errors)

    print_metrics(metrics, cumulative)
    save_reports(df, metrics, cumulative, output_dir, model_path, test_files_path, n_points)
    plot_error_distribution(errors, output_dir)
    plot_pred_vs_gt(df, output_dir)
    visualize_predictions(df, DATA_DIR, output_dir, num_samples=NUM_VISUALIZE)

    print(f'完成。所有评估输出已保存到：{output_dir}')


if __name__ == '__main__':
    main()
