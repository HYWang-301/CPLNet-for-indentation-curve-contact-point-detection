DATA_DIR     = r"C:\Users\admin\Desktop\下游数据智能化分析\力曲线智能识别训练数据\组织+细胞"
LABELS_EXCEL = r"C:\Users\admin\Desktop\下游数据智能化分析\力曲线智能识别训练数据\组织+细胞\contact_points_labels.xlsx"
SAVE_DIR     = r"C:\Users\admin\Desktop\下游数据智能化分析\力曲线智能识别训练数据\Sotres2022_ConvNet1D_结果3 （200 epoch）"

CONFIG = {
    'n_points':      5120,   # Consistent with the original paper
    'epochs':        200,
    'batch_size':    32,
    'learning_rate': 0.0001, # Consistent with the original paper
    'weight_decay':  0.0,    # Consistent with the original paper
    'patience':      1999,
    'train_ratio':   0.70,
    'val_ratio':     0.15,
    'test_ratio':    0.15,
    'num_workers':   16,
    'random_seed':   42,
    'num_visualize': 20,
}

import json
import time
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

class ConvNet1D(nn.Module):
    def __init__(self, n_points: int, l2_reg: float = 1e-4):
        super().__init__()
        self.n_points = n_points

        self.features = nn.Sequential(
            # Block 1
            nn.Conv1d(1, 32, kernel_size=9, padding=4),   # same padding = (9-1)//2
            nn.ReLU(inplace=True),
            nn.MaxPool1d(kernel_size=2, stride=2),

            # Block 2
            nn.Conv1d(32, 64, kernel_size=9, padding=4),
            nn.ReLU(inplace=True),
            nn.MaxPool1d(kernel_size=2, stride=2),

            # Block 3
            nn.Conv1d(64, 128, kernel_size=9, padding=4),
            nn.ReLU(inplace=True),
            nn.MaxPool1d(kernel_size=2, stride=2),
        )

        flat_size = 128 * (n_points // 8)

        self.regressor = nn.Sequential(
            nn.Flatten(),
            nn.Linear(flat_size, 128),  # Dense(128, linear)
            nn.Linear(128, 1),           # Dense(1, linear)
        )

        self.l2_reg = l2_reg

    def forward(self, x):
        # x: [B, 1, L]
        x = self.features(x)
        x = self.regressor(x)
        return x  # [B, 1]

    def get_l2_loss(self):
        l2 = 0.0
        for module in self.features:
            if isinstance(module, nn.Conv1d):
                l2 += (module.weight ** 2).sum()
        for module in self.regressor:
            if isinstance(module, nn.Linear):
                l2 += (module.weight ** 2).sum()
        return self.l2_reg * l2


class AFMDatasetSotres(Dataset):
    def __init__(self, file_list, labels_dict, data_dir,
                 n_points=4096, augment=False):
        self.file_list   = file_list
        self.labels_dict = labels_dict
        self.data_dir    = data_dir
        self.n_points    = n_points
        self.augment     = augment

    def __len__(self):
        return len(self.file_list)

    def _load_deflection(self, filename):
        filepath = os.path.join(self.data_dir, filename)
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
        data = []
        for line in lines:
            line = line.strip()
            if line:
                try:
                    data.append(float(line))
                except ValueError:
                    continue
        data = np.array(data)
        return data[:len(data) // 2]   # 前1/2 = deflection

    def _resample(self, deflection, contact_idx, orig_len):
        """插值到 n_points，同时更新接触点索引"""
        x_old  = np.linspace(0, 1, orig_len)
        x_new  = np.linspace(0, 1, self.n_points)
        defl_rs = np.interp(x_new, x_old, deflection)
        ratio  = self.n_points / orig_len
        new_idx = int(np.clip(contact_idx * ratio, 0, self.n_points - 1))
        return defl_rs, new_idx

    def _normalize_sotres(self, arr):
        rng = arr.max() - arr.min()
        if rng < 1e-8:
            rng = 1.0
        return (arr - arr.mean()) / rng

    def __getitem__(self, idx):
        filename    = self.file_list[idx]
        contact_idx = self.labels_dict[filename]
        deflection  = self._load_deflection(filename)
        orig_len    = len(deflection)
        defl_rs, new_idx = self._resample(deflection, contact_idx, orig_len)
        defl_norm = self._normalize_sotres(defl_rs)

        # 归一化位置标签 [0,1]
        pos_label = new_idx / self.n_points

        signal = torch.tensor(defl_norm, dtype=torch.float32).unsqueeze(0)  # [1, L]
        pos    = torch.tensor(pos_label,  dtype=torch.float32)

        return {
            'signal':                signal,      # [1, n_points]
            'position':              pos,          # scalar
            'resampled_contact_idx': new_idx,      # int
            'original_length':       orig_len,
            'filename':              filename,
            'original_contact_idx':  contact_idx,
        }

def load_labels(excel_path):
    df = pd.read_excel(excel_path)
    labels_dict = {}
    for _, row in df.iterrows():
        labels_dict[str(row['FileName'])] = int(row['ContactIndex'])
    return labels_dict


def create_dataloaders(data_dir, labels_excel, n_points, batch_size,
                       train_ratio, val_ratio, test_ratio,
                       num_workers, random_seed):
    labels_dict = load_labels(labels_excel)
    all_files   = list(labels_dict.keys())
    valid_files = [f for f in all_files
                   if os.path.exists(os.path.join(data_dir, f))]
    print(f"Valid files: {len(valid_files)}")

    np.random.seed(random_seed)
    train_val, test_files = train_test_split(
        valid_files, test_size=test_ratio, random_state=random_seed)
    val_size = val_ratio / (train_ratio + val_ratio)
    train_files, val_files = train_test_split(
        train_val, test_size=val_size, random_state=random_seed)
    print(f"Train: {len(train_files)}, Val: {len(val_files)}, Test: {len(test_files)}")

    ckw = dict(labels_dict=labels_dict, data_dir=data_dir, n_points=n_points)
    train_ds = AFMDatasetSotres(train_files, augment=False, **ckw)
    val_ds   = AFMDatasetSotres(val_files,   augment=False, **ckw)
    test_ds  = AFMDatasetSotres(test_files,  augment=False, **ckw)

    lkw = dict(batch_size=batch_size, num_workers=num_workers, pin_memory=True)
    train_loader = DataLoader(train_ds, shuffle=True,  **lkw)
    val_loader   = DataLoader(val_ds,   shuffle=False, **lkw)
    test_loader  = DataLoader(test_ds,  shuffle=False, **lkw)

    return train_loader, val_loader, test_loader, test_files, labels_dict


@torch.no_grad()
def evaluate_on_loader(model, loader, device, n_points):
    model.eval()
    errors_orig = []
    errors_rs   = []

    for batch in loader:
        signal   = batch['signal'].to(device)          # [B, 1, L]
        gt_rs    = batch['resampled_contact_idx']       # [B]
        gt_orig  = batch['original_contact_idx']       # [B]
        orig_len = batch['original_length']            # [B]

        pred_norm = model(signal).squeeze(1)           # [B]
        pred_rs   = (pred_norm * n_points).long().clamp(0, n_points - 1)

        for i in range(len(pred_rs)):
            pr   = pred_rs[i].item()
            gr   = gt_rs[i].item()
            go   = gt_orig[i].item()
            ol   = orig_len[i].item()

            # 原始空间预测：pred_orig = pred_rs * orig_len / n_points
            po = int(np.clip(pr * ol / n_points, 0, ol - 1))

            errors_rs.append(abs(pr - gr))
            errors_orig.append(abs(po - go))

    return np.array(errors_orig), np.array(errors_rs)


def print_error_distribution(errors_orig, tag='Test'):
    n = len(errors_orig)
    mae = errors_orig.mean()
    print(f"\n{'='*55}")
    print(f"  {tag} — 原始空间 MAE: {mae:.2f} pts  (N={n})")
    print(f"  Median: {np.median(errors_orig):.1f}  Std: {errors_orig.std():.1f}")
    print(f"  Error Distribution:")
    for t in [10, 50, 100, 200, 500]:
        pct = (errors_orig <= t).mean() * 100
        print(f"    <=  {t:4d} pts:  {pct:5.1f}%")
    print(f"{'='*55}")


def train(data_dir, labels_excel, save_dir, config):
    os.makedirs(save_dir, exist_ok=True)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"\n[ConvNet-1D] Device: {device}")

    n_points = config['n_points']

    train_loader, val_loader, test_loader, test_files, labels_dict = create_dataloaders(
        data_dir=data_dir, labels_excel=labels_excel,
        n_points=n_points,
        batch_size=config['batch_size'],
        train_ratio=config['train_ratio'],
        val_ratio=config['val_ratio'],
        test_ratio=config['test_ratio'],
        num_workers=config['num_workers'],
        random_seed=config['random_seed'],
    )

    with open(os.path.join(save_dir, 'test_files.json'), 'w', encoding='utf-8') as f:
        json.dump(test_files, f, ensure_ascii=False, indent=2)

    model = ConvNet1D(n_points=n_points, l2_reg=1e-4).to(device)
    total_params = sum(p.numel() for p in model.parameters())
    print(f"[ConvNet-1D] Parameters: {total_params:,}")

    optimizer = optim.Adam(model.parameters(),
                           lr=config['learning_rate'],
                           betas=(0.9, 0.999))

    best_val_loss = float('inf')
    patience_ctr  = 0
    history       = {'train_loss': [], 'val_loss': [], 'val_mae_orig': []}

    print(f"\n[ConvNet-1D] Training for up to {config['epochs']} epochs "
          f"(patience={config['patience']})...")
    print("-" * 60)

    for epoch in range(config['epochs']):
        t0 = time.time()

        model.train()
        train_losses = []
        for batch in train_loader:
            signal = batch['signal'].to(device)             # [B, 1, L]
            target = batch['position'].to(device).unsqueeze(1)  # [B, 1]

            pred = model(signal)                            # [B, 1]
            mse_loss = nn.functional.mse_loss(pred, target)
            l2_loss  = model.get_l2_loss()
            loss     = mse_loss + l2_loss

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            train_losses.append(mse_loss.item())

        train_loss = np.mean(train_losses)

        model.eval()
        val_losses = []
        with torch.no_grad():
            for batch in val_loader:
                signal = batch['signal'].to(device)
                target = batch['position'].to(device).unsqueeze(1)
                pred   = model(signal)
                val_losses.append(nn.functional.mse_loss(pred, target).item())
        val_loss = np.mean(val_losses)

        val_mae_orig = -1.0
        if (epoch + 1) % 5 == 0 or epoch == 0:
            err_o, _ = evaluate_on_loader(model, val_loader, device, n_points)
            val_mae_orig = err_o.mean()

        history['train_loss'].append(train_loss)
        history['val_loss'].append(val_loss)
        history['val_mae_orig'].append(val_mae_orig)

        elapsed = time.time() - t0
        if (epoch + 1) % 50 == 0 or epoch == 0:
            print(f"Epoch {epoch+1:>5}/{config['epochs']}  "
                  f"Train MSE: {train_loss:.6f}  "
                  f"Val MSE: {val_loss:.6f}  "
                  f"Val MAE(orig): {val_mae_orig:.1f}  "
                  f"({elapsed:.1f}s)")

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_ctr  = 0
            torch.save({
                'epoch':            epoch + 1,
                'model_state_dict': model.state_dict(),
                'val_loss':         val_loss,
                'config':           config,
            }, os.path.join(save_dir, 'best_val_loss.pth'))
        else:
            patience_ctr += 1
            if patience_ctr >= config['patience']:
                print(f"\n[ConvNet-1D] Early stopping at epoch {epoch+1} "
                      f"(best val MSE: {best_val_loss:.6f})")
                break

    with open(os.path.join(save_dir, 'history.json'), 'w') as f:
        json.dump(history, f, indent=2)
    _plot_history(history, save_dir)

    print("\n[ConvNet-1D] Loading best model for final evaluation...")
    ckpt = torch.load(os.path.join(save_dir, 'best_val_loss.pth'),
                      map_location=device, weights_only=False)
    model.load_state_dict(ckpt['model_state_dict'])
    print(f"  Best epoch: {ckpt['epoch']}, Val MSE: {ckpt['val_loss']:.6f}")

    err_test_orig, err_test_rs = evaluate_on_loader(model, test_loader, device, n_points)
    print_error_distribution(err_test_orig, tag='[ConvNet-1D] Test Set')

    print(f"\n  [Resampled Space ({n_points} pts) — for reference]")
    print(f"    MAE: {err_test_rs.mean():.2f}  Median: {np.median(err_test_rs):.1f}")

    # 保存结果
    result_path = os.path.join(save_dir, 'test_results.json')
    with open(result_path, 'w') as f:
        json.dump({
            'model': 'ConvNet-1D (Sotres et al. 2022)',
            'n_points': n_points,
            'test_mae_orig': float(err_test_orig.mean()),
            'test_median_orig': float(np.median(err_test_orig)),
            'test_mae_rs': float(err_test_rs.mean()),
            'error_distribution': {
                f'<={t}pts': float((err_test_orig <= t).mean() * 100)
                for t in [10, 50, 100, 200, 500]
            }
        }, f, indent=2)
    print(f"\n[ConvNet-1D] Results saved to: {save_dir}")

    return model, test_files, labels_dict


def _plot_history(history, save_dir):
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    ep = range(1, len(history['train_loss']) + 1)
    axes[0].plot(ep, history['train_loss'], 'b-', label='Train')
    axes[0].plot(ep, history['val_loss'],   'r-', label='Val')
    axes[0].set_title('Loss (MSE) — ConvNet-1D'); axes[0].legend(); axes[0].grid(True, alpha=0.3)
    axes[0].set_xlabel('Epoch'); axes[0].set_ylabel('MSE')

    mae_vals = [(i+1, m) for i, m in enumerate(history['val_mae_orig']) if m >= 0]
    if mae_vals:
        ep2, mv = zip(*mae_vals)
        axes[1].plot(ep2, mv, 'g-o', ms=3, label='Val MAE (orig pts)')
        axes[1].set_title('Val MAE (Original Space) — ConvNet-1D')
        axes[1].legend(); axes[1].grid(True, alpha=0.3)
        axes[1].set_xlabel('Epoch'); axes[1].set_ylabel('MAE (pts)')

    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, 'training_curves.png'), dpi=150)
    plt.close()



def main():
    print("\n" + "=" * 60)
    print("  Sotres et al. 2022 — ConvNet-1D (PyTorch 复现)")
    print("  Single-channel deflection | MSE loss | Adam lr=1e-4")
    print("=" * 60)

    for path, name in [(DATA_DIR, 'DATA_DIR'), (LABELS_EXCEL, 'LABELS_EXCEL')]:
        if not os.path.exists(path):
            print(f"[错误] {name} 不存在: {path}")
            input("按 Enter 退出...")
            return

    import torch
    print(f"\nPyTorch: {torch.__version__}")
    if torch.cuda.is_available():
        print(f"GPU: {torch.cuda.get_device_name(0)}")
    else:
        print("[警告] 使用 CPU，训练会很慢")

    print(f"\n配置:")
    for k, v in CONFIG.items():
        print(f"  {k}: {v}")

    print("\n按 Enter 开始训练...")
    try:
        input()
    except KeyboardInterrupt:
        print("\n取消")
        return

    torch.manual_seed(CONFIG['random_seed'])
    np.random.seed(CONFIG['random_seed'])

    train(
        data_dir=DATA_DIR,
        labels_excel=LABELS_EXCEL,
        save_dir=SAVE_DIR,
        config=CONFIG,
    )

    input("\n按 Enter 退出...")


if __name__ == '__main__':
    main()
